/* gauss_seidel.h - Poisson problem
 *
 */
#ifndef _GAUSS_SEIDEL_PAR_H
#define _GAUSS_SEIDEL_PAR_H

void gauss_seidel_par(double ***, double ***, int, int);

#endif
